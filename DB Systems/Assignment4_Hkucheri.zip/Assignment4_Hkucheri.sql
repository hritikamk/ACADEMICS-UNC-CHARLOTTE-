-- CREATE DATABASE
CREATE DATABASE assignment4;

-- USE THE DATABASE
USE assignment4;

-- 1. PERSON (Supertype)
CREATE TABLE Person (
    PersonID VARCHAR(10) PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    DateOfBirth DATE,
    Email VARCHAR(100),
    Address VARCHAR(100),
    Cell VARCHAR(20)
);

-- 2. PATIENT (Subtype)
CREATE TABLE Patient (
    PersonID VARCHAR(10) PRIMARY KEY,
    MedicalHistory TEXT,
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);

-- 3. DOCTOR (Subtype)
CREATE TABLE Doctor (
    PersonID VARCHAR(10) PRIMARY KEY,
    HireDate DATE,
    Specialty VARCHAR(50),
    DepartmentID VARCHAR(10),
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);

-- 4. STAFF (Subtype)
CREATE TABLE Staff (
    PersonID VARCHAR(10) PRIMARY KEY,
    HireDate DATE,
    Position VARCHAR(50),
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);

-- 5. DEPARTMENT
CREATE TABLE Department (
    DepartmentID VARCHAR(10) PRIMARY KEY,
    DepartmentName VARCHAR(50)
);

-- 6. TREATMENT
CREATE TABLE Treatment (
    TreatmentID VARCHAR(10) PRIMARY KEY,
    TreatmentName VARCHAR(50),
    Cost DECIMAL(10, 2)
);

-- 7. VISIT (Weak entity)
CREATE TABLE Visit (
    PatientID VARCHAR(10),
    VisitNum INT,
    VisitDate DATE,
    Reason TEXT,
    PersonID VARCHAR(10), -- Doctor assigned
    PRIMARY KEY (PatientID, VisitNum),
    FOREIGN KEY (PatientID) REFERENCES Patient(PersonID),
    FOREIGN KEY (PersonID) REFERENCES Doctor(PersonID)
);

-- 8. VISITTREATMENT (Associative entity)
CREATE TABLE VisitTreatment (
    VisitID_PatientID VARCHAR(10),
    VisitID_VisitNum INT,
    TreatmentID VARCHAR(10),
    TreatmentDate DATE,
    PersonID VARCHAR(10), -- Staff assigned
    PRIMARY KEY (VisitID_PatientID, VisitID_VisitNum, TreatmentID),
    FOREIGN KEY (VisitID_PatientID, VisitID_VisitNum) REFERENCES Visit(PatientID, VisitNum),
    FOREIGN KEY (TreatmentID) REFERENCES Treatment(TreatmentID),
    FOREIGN KEY (PersonID) REFERENCES Staff(PersonID)
);

-- INSERT INTO PERSON (7 total)
INSERT INTO Person VALUES
('P001', 'John', 'Smith', '1980-03-15', 'john.smith@email.com', '101 Main St', '555-123-4567'),
('P002', 'Sarah', 'Lee', '1992-06-20', 'sarah.lee@email.com', '202 Elm St', '555-234-5678'),
('P003', 'Alice', 'Kim', '1985-10-10', 'alice.kim@email.com', '303 Oak Ave', '555-345-6789'),
('P004', 'Michael', 'Brown', '1978-08-05', 'michael.b@email.com', '404 Pine Rd', '555-456-7890'),
('P005', 'Emma', 'Davis', '1990-12-01', 'emma.d@email.com', '505 Maple Blvd', '555-567-8901'),
('P006', 'Robert', 'White', '1982-11-22', 'robert.w@email.com', '606 Cedar Ln', '555-678-9012'),
('P007', 'Lisa', 'Hall', '1995-07-19', 'lisa.h@email.com', '707 Birch Ct', '555-789-0123');

-- INSERT INTO PATIENT (3 total, one overlaps with Staff)
INSERT INTO Patient VALUES
('P001', 'Allergic to penicillin'),
('P002', 'No major issues'),
('P006', 'Type 2 Diabetes');

-- INSERT INTO DOCTOR (2 total)
INSERT INTO Doctor VALUES
('P003', '2010-04-01', 'Pediatrics', 'D01'),
('P004', '2008-09-12', 'Radiology', 'D02');

-- INSERT INTO STAFF (2 total, including overlapping patient)
INSERT INTO Staff VALUES
('P005', '2015-03-15', 'Nurse'),
('P006', '2018-07-10', 'Lab Technician');

-- INSERT INTO DEPARTMENT
INSERT INTO Department VALUES
('D01', 'Pediatrics'),
('D02', 'Radiology');

-- INSERT INTO TREATMENT
INSERT INTO Treatment VALUES
('T001', 'Vaccination', 50.00),
('T002', 'MRI', 500.00),
('T003', 'Blood Transfusion', 250.00),
('T004', 'X-Ray', 120.00);

-- INSERT INTO VISIT (2 total)
INSERT INTO Visit VALUES
('P001', 1, '2025-06-01', 'Routine Checkup', 'P003'),
('P002', 1, '2025-06-02', 'Severe Headache', 'P004');

-- INSERT INTO VISITTREATMENT (each visit has 2 treatments)
INSERT INTO VisitTreatment VALUES
('P001', 1, 'T001', '2025-06-01', 'P005'),
('P001', 1, 'T004', '2025-06-01', 'P006'),
('P002', 1, 'T002', '2025-06-02', 'P006'),
('P002', 1, 'T003', '2025-06-02', 'P005');

SELECT * FROM Person;
SELECT * FROM Patient;
SELECT * FROM Doctor;
SELECT * FROM Staff;
SELECT * FROM Department;
SELECT * FROM Treatment;
SELECT * FROM Visit;
SELECT * FROM VisitTreatment;