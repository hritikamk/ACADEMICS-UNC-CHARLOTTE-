Graph Algorithms Overview

This folder contains Java programs for various graph algorithms, such as Topological Sorting using Depth First Search (DFS), Dijkstra's Algorithm for shortest paths, and Kruskal's Algorithm for Minimum Spanning Tree (MST). Each algorithm is coded in its own Java file and designed to read graph data from input files.

Contents

1.DfsAndTs.java: Implements DFS for cycle detection and topological sorting in directed graphs, located in the TopologicalSort folder.

2.Dijkstra.java: Implements Dijkstra's Algorithm to calculate the shortest paths from a given source vertex to all other vertices in a graph.

3.Kruskal.java: Implements Kruskal's Algorithm to find the MST of an undirected graph.

4.InputFiles folder: Contains sample graphs in both directed and undirected formats. Graph files start with the number of vertices, edges, and type (D for Directed, U for Undirected), followed by an edge list and an optional source vertex. The "InputFiles" folder includes files for Dijkstra's and Kruskal's algorithms, while the "InputFiles" folder under TopologicalSort contains files for topological sorting.


Prerequisites:

*Java Development Kit (JDK): Install JDK 11 or newer from Oracle's website.
*Visual Studio Code: Download and install from here.
*Java Extension Pack for VS Code: Available on the VS Code marketplace, this pack contains essential Java development tools.

Usage:

1.To execute Dijkstra's and Kruskal's algorithms, run the Main.java file in the dijkstraAndKruskal directory using the run and debug option in VS Code.

2.Use the on-screen prompts to select an input file and view outputs like shortest paths and MST.

Sample Input File Format:

6 8 D
A B 6
A D 1
B D 2
B E 2
C A 3
D E 1
D C 1
E F 2
A

*The first line indicates the graph's vertices (6), edges (8), and type (D for Directed).
*Following lines detail the edges with their start and end vertices, along with the weights.
*The final line, which is optional, denotes the source vertex for applicable algorithms.
