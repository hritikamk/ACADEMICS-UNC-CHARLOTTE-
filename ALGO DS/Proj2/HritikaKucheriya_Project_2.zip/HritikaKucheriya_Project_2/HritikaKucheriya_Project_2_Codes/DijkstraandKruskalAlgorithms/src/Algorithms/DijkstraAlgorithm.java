package Algorithms;

import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class DijkstraAlgorithm {
	
	Scanner sc=null;
	FileReader fileReader=null;
	
	 int source,edges,vertex;
	 int adjacentMatrix[][];
	 int[] distanceFromSource;
	 int[] path;
	 
	String alphabetStream="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	String filedata=null;

    boolean graphtype=false;
   
    public void fileReader(String filePath) throws Exception 
    {
        fileReader=new FileReader(new File(filePath));
        if(fileReader!=null) 
        {
            sc = new Scanner(fileReader);
            if((filedata=sc.nextLine())!=null) 
            {
                String[] temp=filedata.split(" ");
                
                //Check if the graph is Directed Graph or Undirected Graph
                if(temp[2].equals("D")) 
                {
                    graphtype=true;
                    System.out.println("Directed Graph");
                }
                else
                {
                    System.out.println("Undirected Graph");
                }
                
                vertex=Integer.parseInt(temp[0]);
                System.out.println("Number of Vertices: "+vertex);

                adjacentMatrix=new int[vertex][vertex];

                edges=Integer.parseInt(temp[1]);
                System.out.println("Number of Edges: "+edges);

                for(int index=0;index<edges;index++) 
                {
                    filedata=sc.nextLine();
                    temp=filedata.split(" ");
                    adjacentMatrix[alphabetStream.indexOf(temp[0].charAt(0))][alphabetStream.indexOf(temp[1].charAt(0))]=Integer.parseInt(temp[2]);
                    if(graphtype!=true) 
                    {
                        adjacentMatrix[alphabetStream.indexOf(temp[1].charAt(0))][alphabetStream.indexOf(temp[0].charAt(0))]=Integer.parseInt(temp[2]);
                    }
                }
                if(sc.hasNext()) 
                {
                    filedata=sc.nextLine();
                    source=alphabetStream.indexOf(filedata.charAt(0));
                    System.out.println("\nSource:  "+filedata.charAt(0)+"\n");
                }
                else 
                {
                        source=0;
                        System.out.println("\nSource node is not specified. Selecting \n"+alphabetStream.charAt(0)+" as the Source.\n");
                }
            }
        }
    }
    void dijkstraAlgorithm() 
    {
    	path=new int[vertex];
    	boolean[] visitedVertice=new boolean[vertex];
        distanceFromSource=new int[vertex];

        for(int i=0;i<vertex;i++) 
        {
            distanceFromSource[i]=Integer.MAX_VALUE;
            visitedVertice[i]=false;
        }  
        distanceFromSource[source]=0;
        path[source]=-1;

        for(int i=0;i<vertex;i++) 
        {
            int nextVertice=-1;
            int shortestDistanceFromSource=Integer.MAX_VALUE;
            
            for(int j=0;j<vertex;j++) 
            {
                if(visitedVertice[j]==false && distanceFromSource[j]<shortestDistanceFromSource) 
                {
                    nextVertice=j;
                    shortestDistanceFromSource=distanceFromSource[j];
                }
            }

            visitedVertice[nextVertice]=true;

            for(int j=0;j<vertex;j++) 
            {
                int distanceFromEdge=adjacentMatrix[nextVertice][j];
                if (distanceFromEdge > 0 && ((shortestDistanceFromSource + distanceFromEdge) < distanceFromSource[j])) 
                {
                    path[j] = nextVertice;
                    distanceFromSource[j] = shortestDistanceFromSource + distanceFromEdge;
                }
            }
        }
    }

    public void getResult() 
    {
        System.out.print("Distance from Source to other Vertices:\n");
        for (int i = 0; i < vertex; i++)
        {
            if (i!= source)
            {
                int v=i;
                String str="";
                while(path[v]!=-1) 
                {
                    str=" --> "+alphabetStream.charAt(v)+str;
                    v=path[v];
                }
                System.out.print("\n" + alphabetStream.charAt(source)+str+ " Cost: ");
                System.out.print(distanceFromSource[i]);
            }
        }
    }
}
