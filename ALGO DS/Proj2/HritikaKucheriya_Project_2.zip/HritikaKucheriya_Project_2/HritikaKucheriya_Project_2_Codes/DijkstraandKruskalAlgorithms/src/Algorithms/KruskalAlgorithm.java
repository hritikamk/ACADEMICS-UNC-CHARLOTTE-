package Algorithms;

import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Scanner;

public class KruskalAlgorithm 
{
	
	Scanner sc = null;
    int edgeIndex,vertex, edges;
    Path result[], edgeArray[];
    FileReader fileReader = null;
    
    String alphabetStream = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    
    class Src 
    {
        int p, q;
    }
    
    public void fileReader(String filePath) throws Exception 
    {
        fileReader = new FileReader(new File(filePath));
        sc = new Scanner(fileReader);
        vertex = sc.nextInt();
        edges = sc.nextInt();
        System.out.println("Number of vertices: "+vertex);
        System.out.println("Number of Edges: "+edges);

        sc.next().charAt(0);
        edgeArray = new Path[edges];
        for (int i = 0; i < edges; ++i) 
        {
            edgeArray[i] = new Path();
        }

        for (int i = 0; i < edges; i++) {
            int source = alphabetStream.indexOf(sc.next().charAt(0));
            int destination = alphabetStream.indexOf(sc.next().charAt(0));
            int weight = sc.nextInt();
            edgeArray[i].source = source;
            edgeArray[i].destination = destination;
            edgeArray[i].weight = weight;
        }
    }

    void union(Src s[], int x, int y) 
    {
        int value1 = find(s, x);
        int value2 = find(s, y);
        if (s[value1].q > s[value2].q)
            s[value2].p = value1;
        else if (s[value1].q < s[value2].q)
            s[value1].p = value2;
        else 
        {
            s[value2].p = value1;
            s[value1].q++;
        }
    }
    
    int find(Src src[], int i) 
    {
        if (src[i].p != i)
            src[i].p = find(src, src[i].p);
        return src[i].p;
    }

    void kruskalAlgorithm() 
    {
        result = new Path[vertex];
        edgeIndex = 0;
        int index;
        for (index = 0; index < vertex; ++index) 
        {
            result[index] = new Path();
        }
        Arrays.sort(edgeArray);
        Src s[] = new Src[vertex];
        for (index = 0; index < vertex; ++index) 
        {
            s[index] = new Src();
        }
        for (int i = 0; i < vertex; ++i) 
        {
            s[i].p = i;
            s[i].q = 0;
        }
        index = 0;
        while (edgeIndex < vertex - 1)
        {
            Path next_edge;
            next_edge = edgeArray[index++];
            int x = find(s, next_edge.source);
            int y = find(s, next_edge.destination);
            if (x != y)
            {
                result[edgeIndex++] = next_edge;
                union(s, x, y);
            }
        }
    }
    public void showResult() 
    {
        int totalCost=0;
        System.out.println("\nMinimum Spanning Tree: \n");
        for (int i = 0; i < edgeIndex; ++i) 
        {
            System.out.println((alphabetStream.charAt(result[i].source)) + " --> " + alphabetStream.charAt(result[i].destination) + " Cost: " + result[i].weight);
            totalCost += result[i].weight;
        }
        System.out.println("\nTotal Cost of MST: "+totalCost);
    }
    class Path implements Comparable<Path> 
    {
        int source, destination, weight;
        public int compareTo(Path compareEdge) 
        {
            return this.weight - compareEdge.weight;
        }
    }

}
