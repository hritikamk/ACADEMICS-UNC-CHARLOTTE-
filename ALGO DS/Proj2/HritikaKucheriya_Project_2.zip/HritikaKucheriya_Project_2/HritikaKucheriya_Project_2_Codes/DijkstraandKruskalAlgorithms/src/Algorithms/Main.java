/*
 * Project 2
 * Sushanth Rangu 801366053
 * Sudhish Cherukuri 801366050
 * */

package Algorithms;
import java.util.Scanner;
public class Main 
{
	public static void main(String[] args) throws Exception 
	{
		DijkstraAlgorithm dijkstraAlgorithm = new DijkstraAlgorithm();
		KruskalAlgorithm kruskalAlgorithm = new KruskalAlgorithm();
		long algorithmStartTime, algorithmEndTime, totalTime;
		
		Scanner sc = new Scanner(System.in);
        String filePath = null;    
        int ipFile;
      
        //Choose which algorithm to execute. 
        System.out.println("Select an Algorithm:\n" + "1.Dijkstra's Algorithm\n" + "2.Kruskal's Algorithm");
        int ch = Integer.parseInt(sc.nextLine());
        
        switch (ch) {
		case 1:
			//Select the type of graph (Directed or Undirected)
			System.out.println("Select an Input File\n" +
			                   "1.UnDirected Graph-Input1\n" +
					           "2.UnDirected Graph-Input2\n" +
			                   "3.UnDirected Graph-Input3.\n" +
					           "4.UnDirected Graph-Input4.\n"+
							   "5.UnDirected Graph-Input5.\n"+
			                   "6.Directed Graph-Input6.\n"+
			                   "7.Directed Graph-Input7.\n"+
			                   "8.Directed Graph-Input8.\n"+
			                   "9.Directed Graph-Input9.");
			ipFile = Integer.parseInt(sc.nextLine());
			filePath = getFilePath(ipFile);
			
			//Dijkstra's algorithm for Undirected/Directed Graph
			System.out.println("------------- Dijkstra's Algorithm ------------\n");
			dijkstraAlgorithm.fileReader(filePath);
			algorithmStartTime = System.nanoTime();
			dijkstraAlgorithm.dijkstraAlgorithm();
			algorithmEndTime = System.nanoTime();
			dijkstraAlgorithm.getResult();
			System.out.println("\n\n Execution time for Dijkstra's Algorithm in nanoseconds: "+(algorithmEndTime-algorithmStartTime));
			break;
			
		case 2:
			//Select the type of graph (Directed or Undirected)
			System.out.println("Select an Input File:\n" +
						"1.UnDirected Graph-Input1\n" +
			           "2.UnDirected Graph-Input2.\n" +
	                   "3.UnDirected Graph-Input3.\n" +
			           "4.UnDirected Graph-Input4.\n"+
					   "5.UnDirected Graph-Input5.\n") ;
			ipFile = Integer.parseInt(sc.nextLine());
			filePath = getFilePath(ipFile);
			
			//Kruskal's algorithm for Undirected Graph
			System.out.println("------------- Kruskal's Algorithm --------------\n");
			kruskalAlgorithm.fileReader(filePath);
	
			//Start Timer
			algorithmStartTime = System.nanoTime();
			
			kruskalAlgorithm.kruskalAlgorithm();
			
			//Stop Timer
			algorithmEndTime = System.nanoTime();
			
			kruskalAlgorithm.showResult();
			totalTime = algorithmEndTime-algorithmStartTime;
			System.out.println("\n Execution time for Kruskal's Algorithm in nanoseconds : "+(totalTime));
			break;
		default:
			System.out.println("Error!! Invalid Input.");
			break;
		}
        sc.close();
	}
	
	static String getFilePath(int ipfile) {
		String fPath;
		switch (ipfile) {
		case 1:
			fPath = "DijkstraandKruskalAlgorithms/InputFiles/UndirectedGraph_Input1";
			break;
		case 2:
			fPath = "DijkstraandKruskalAlgorithms/InputFiles/UndirectedGraph_Input2";
			break;
		case 3:
			fPath = "DijkstraandKruskalAlgorithms/InputFiles/UndirectedGraph_Input3";
			break;
		case 4:
			fPath = "DijkstraandKruskalAlgorithms/InputFiles/UndirectedGraph_Input4";
			break;
		case 5:
			fPath = "DijkstraandKruskalAlgorithms/InputFiles/undirectedGraph_Input5";
			break;
		case 6:
			fPath = "DijkstraandKruskalAlgorithms/InputFiles/DirectedGraph_Input6";
			break;
		case 7:
			fPath = "DijkstraandKruskalAlgorithms/InputFiles/DirectedGraph_Input7";
			break;
		case 8:
			fPath = "DijkstraandKruskalAlgorithms/InputFiles/DirectedGraph_Input8";
			break;
		case 9:
			fPath = "DijkstraandKruskalAlgorithms/InputFiles/DirectedGraph_Input9";
			break;
		default:
			System.out.println("Invalid Input!!\n");
			fPath = "InputFiles/UndirectedGraph_Input1";
			break;
		}
		return fPath;
	}
}

