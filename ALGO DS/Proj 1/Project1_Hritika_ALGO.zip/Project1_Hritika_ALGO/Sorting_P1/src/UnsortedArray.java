import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class UnsortedArray {
	
	private static final int RANGE_OF_NUMBERS = 5000;
	private static final Random rand = new Random();

	public static void main(String[] args) {
		
			// Scanner to get the input size from user 
	        Scanner in = new Scanner(System.in); 
	        System.out.println("Enter the number of elements to be sorted :");
	        int n = in.nextInt();
	        in.close();
	       
	        
	        // Initializing arrays with random numbers
			int array[] = getRandomNumberArray(n);
			int array1[] = Arrays.copyOf(array, array.length);
			int array2[] = Arrays.copyOf(array, array.length);
			int array3[] = Arrays.copyOf(array, array.length);
			int array4[] = Arrays.copyOf(array, array.length);
			
			
	        //INSERTION SORT
			System.out.println("INSERTION SORT");
	        System.out.println("Original Array: "+Arrays.toString(array));
	        long executionstarttime = System.nanoTime();
	        InsertionSort(array);
	        long executionendtime = System.nanoTime();
	        System.out.println("Sorted Array: "+Arrays.toString(array));
	        System.out.println("Execution time in nanoseconds: "+(executionendtime-executionstarttime));
	        
	        System.out.println("\n");
	        
	        
	        //MERGE SORT
	        System.out.println("MERGE SORT");
	        System.out.println("Original Array: "+Arrays.toString(array1));
	        long  executionstarttime1 = System.nanoTime();     
	        mergesort(array1, 0, array1.length-1); 
	        long executionendtime1 = System.nanoTime();
	        System.out.println("Sorted Array: "+Arrays.toString(array1));
	        System.out.println("Execution time in nanoseconds:"+(executionendtime1-executionstarttime1));
	        
	        System.out.println("\n");
	        
	        
	        //HEAP SORT
	        System.out.println("HEAP SORT");
	        System.out.println("Original Array: "+Arrays.toString(array2));
	        long executionstarttime2 = System.nanoTime();     
	        heapsort(array2);
	        long executionendtime2 = System.nanoTime();        
	        System.out.println("Sorted Array: "+Arrays.toString(array2));
	        System.out.println("Execution time in nanoseconds:"+(executionendtime2-executionstarttime2));
	        
	        System.out.println("\n");
	        
	        
	        //INPLACE QUICK SORT
	        System.out.println("INPLACE QUICK SORT");
	        System.out.println("Original Array: "+Arrays.toString(array3));
	        long executionstarttime3 = System.nanoTime();
	        inPlaceQuickSort(array3, 0, array3.length-1);
	        long executionendtime3 = System.nanoTime();
	        System.out.println("Sorted Array: "+Arrays.toString(array3));
	        System.out.println("Execution time in nanoseconds:"+(executionendtime3-executionstarttime3));
	        
	        System.out.println("\n");
	        
	       
	        //MODIFIED QUICK SORT
	        System.out.println("MODIFIED QUICK SORT");
	        System.out.println("Original Array: "+Arrays.toString(array4));
	        long executionstarttime4 = System.nanoTime();
	        medianQuickSort(array4, 0, array4.length-1);
	        long executionendtime4 = System.nanoTime();
	        System.out.println("Sorted Array: "+Arrays.toString(array4));
	        System.out.println("Execution time in nanoseconds:"+(executionendtime4-executionstarttime4));
			
			System.out.println("\n");
			
			System.out.println("Execution time for Insertion Sort in nanoseconds: "+(executionendtime-executionstarttime));
            System.out.println("Execution time for Merge Sort in nanoseconds:"+(executionendtime1-executionstarttime1));
            System.out.println("Execution time for Heap Sort in nanoseconds:"+(executionendtime2-executionstarttime2));
            System.out.println("Execution time for In-Place Quick Sort in nanoseconds:"+(executionendtime3-executionstarttime3));
            System.out.println("Execution time for Modified Quick Sort in nanoseconds:"+(executionendtime4-executionstarttime4));
	        
	}
	
	
	//Function for insertion sort
    static void InsertionSort(int array[]) 
    { 
        int n = array.length; 
        for (int i=1; i<n; ++i) 
        { 
            int key = array[i]; 
            int j = i-1; 
  
            // Move elements of array[0..i-1] to the right by one position that are greater than key
            while (j>=0 && array[j] > key) 
            { 
                array[j+1] = array[j]; 
                j = j-1; 
            } 
            array[j+1] = key; 
        } 
    } 
    
    
    // Function for merge sort
    private static void mergesort(int arr[], int l, int r) 
    { 
        if (l < r) 
        { 
            // Find the middle point 
            int m = (l+r)/2; 
  
            // Sort first and second halves 
            mergesort(arr, l, m); 
            mergesort(arr , m+1, r); 
  
            // Merge the sorted halves 
            merge(arr, l, m, r); 
        } 
    }
    
     // Merge two subarrays of arr[]
    // First subarray is arr[l..m] 
    // Second subarray is arr[m+1..r] 
    private static void merge(int arr[], int l, int m, int r) 
    { 
        // Find the sizes of two sub arrays to be merged 
        int n1 = m - l + 1; 
        int n2 = r - m; 
  
        // Create temp arrays to store the values of two sub arrays
        int L[] = new int [n1]; 
        int R[] = new int [n2]; 
  
        // Copy data to temp arrays
        for (int i=0; i<n1; ++i) 
            L[i] = arr[l + i]; 
        for (int j=0; j<n2; ++j) 
            R[j] = arr[m + 1+ j]; 
  
  
        // Merge the temp arrays 
  
        // Initial indexes of first and second sub arrays 
        int i = 0, j = 0; 
  
        // Initial index of merged sub array 
        int k = l; 
        while (i < n1 && j < n2) 
        { 
            if (L[i] <= R[j]) 
            { 
                arr[k] = L[i]; 
                i++; 
            } 
            else
            { 
                arr[k] = R[j]; 
                j++; 
            } 
            k++; 
        } 
  
        // Copy remaining elements of L[] if any 
        while (i < n1) 
        { 
            arr[k] = L[i]; 
            i++; 
            k++; 
        } 
  
        // Copy remaining elements of R[] if any 
        while (j < n2) 
        { 
            arr[k] = R[j]; 
            j++; 
            k++; 
        } 
    } 
	
    
    //Function for heap sort
    public static void heapsort(int arr[])
    {
        int n = arr.length;
 
      // Build max heap
        for (int i = n / 2 - 1; i >= 0; i--) {
          heapify(arr, n, i);
        }
           
 
        // Heap sort
        for (int i=n-1; i>=0; i--)
        {
            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;
 
          // Heapify root element
            heapify(arr, i, 0);
        }
    }
 
    public static void heapify(int arr[], int n, int i)
    {
      // Find largest element among root, left child and right child
        int largest = i;
        int l = 2*i + 1;
        int r = 2*i + 2;  
 
        if (l < n && arr[l] > arr[largest])
            largest = l;
 
        if (r < n && arr[r] > arr[largest])
            largest = r;
 
      // If root is not largest, swap and continue heapifying
        if (largest != i)
        {
            int swap = arr[i];
            arr[i] = arr[largest];
            arr[largest] = swap;
 
            heapify(arr, n, largest);
        }
    }
    
    
	//Function for in-place quick sort
	private static void inPlaceQuickSort(int[] array3, int left, int right) {
		if(left >= right)
			return;
		final int randomNumRange = right - left + 1;
		int pivot = rand.nextInt(randomNumRange) + left;
		int newPivot = inPlacePartition(array3, left, right, pivot);
		
		inPlaceQuickSort(array3, left, newPivot-1);
		inPlaceQuickSort(array3, newPivot+1, right);
	}
	
	private static int inPlacePartition(int[] array3, int left, int right, int pivot) {
		int pivotValue = array3[pivot];
		
		swapArray(array3, pivot, right);
		
		int tempIndex = left;
		for(int i = left; i <= (right - 1); i++) {
            if(array3[i] < pivotValue) {
                swapArray(array3, i, tempIndex);
                tempIndex++;
            }
        }

        swapArray(array3, tempIndex, right);

        return tempIndex;
	}
	
	private static void swapArray(int[] array3, int a, int b) {
		int temp = array3[a];
		array3[a] = array3[b];
		array3[b] = temp;
	}

  
    //Function for modified quick sort
	private static void medianQuickSort(int[] array4, int left, int right) {		
		if(left + 10 <= right) {
			int pivot = getMedian(array4, left, right);
			int partitionIndex = partition(array4, left, right, pivot);
			medianQuickSort(array4, left, partitionIndex-1);
			medianQuickSort(array4, partitionIndex+1, right);		
		}else {
			//Insertion sort is called for small arrays
            InsertionSort(array4);
		}
	}
	
	private static int partition(int[] array4, int left, int right, int pivot) {
		int i = left, j = right - 1;
		while(true) {
			while(array4[++i] < pivot)
				;
			while(pivot < array4[--j])
				;
			if(i >= j)
				break;
			else
				swap(array4, i, j);
		}
		swap(array4, i, right-1);
		return i;
	}
	
	private static int getMedian(int[] array4, int left, int right) {
		int center = (left+right)/2;
		
		if(array4[center] < array4[left])
			swap(array4, center, left);
		if(array4[right] < array4[left])
			swap(array4, right, left);
		if(array4[right] < array4[center])
			swap(array4, right, center);
		
		swap(array4, center, right-1);
		
		return array4[right-1];
	}
	
	private static void swap(int[] array4, int a, int b) {
		int temp = array4[a];
		array4[a] = array4[b];
		array4[b] = temp;
	}
    	
	
	// Function for loading array with random numbers
    private static int[] getRandomNumberArray(int arrayLength) {
		int[] array = new int[arrayLength];
		for(int i = 0; i < array.length; i++) {
			array[i] = rand.nextInt(RANGE_OF_NUMBERS);
		}
		return array;
	}
}
